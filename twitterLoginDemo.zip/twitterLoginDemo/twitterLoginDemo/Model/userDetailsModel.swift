//
//  userDetailsModel.swift
//  twitterLoginDemo
//
//  Created by admin on 11/10/21.
//

import Foundation

struct userDetailsModel : Decodable {
    let description : String?
    let followers_count : Int?
    let friends_count : Int?
    let name : String?
    let profile_image_url : String?
    let profile_image_url_https : String?
    let screen_name : String?
}
