//
//  FriendDetailsModel.swift
//  twitterLoginDemo
//
//  Created by admin on 11/10/21.
//

import Foundation
struct FriendDetailsModel : Decodable {
    let users : [listDetailsModel]?
    let next_cursor_str : String?
}

struct listDetailsModel : Decodable {
    let description : String?
    let followers_count : Int?
    let friends_count : Int?
    let name : String?
    let profile_image_url : String?
    let profile_image_url_https : String?
    let screen_name : String?
}
