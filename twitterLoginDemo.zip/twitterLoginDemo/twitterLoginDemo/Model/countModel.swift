//
//  countModel.swift
//  twitterLoginDemo
//
//  Created by admin on 11/10/21.
//

import Foundation

struct countModel : Decodable {
    let ids : [Int]?
    let pre_cursor : Int?
    let next_cursor : Int?
    let pre_cursor_str : String?
    let next_cursor_str : String?
}
