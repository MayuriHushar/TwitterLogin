//
//  AppDelegate.swift
//  twitterLoginDemo
//
//  Created by admin on 09/10/21.
//

import UIKit
import TwitterKit
@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        // check user logged in or not
        self.window = UIWindow(frame: UIScreen.main.bounds)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
       
        if UserDefaults.standard.bool(forKey: "isloggedIn"){
            let vc = storyboard.instantiateViewController(withIdentifier: "naViewController") as? naViewController
            window?.rootViewController = vc
            window?.makeKeyAndVisible()
        }else{
            let vc = storyboard.instantiateViewController(withIdentifier: "ViewController") as? ViewController
            window?.rootViewController = vc
            window?.makeKeyAndVisible()
        }
        
        TWTRTwitter.sharedInstance().start(withConsumerKey:"Sh4JYw4aQ773emLJTL9zlFFF2", consumerSecret:"KYZk6x2O0HO8e1ClUyqDDMjXOnYJhjwHBXrY4PJ6M7OFBxkE7z")
        
        return true
    }

    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        return TWTRTwitter.sharedInstance().application(app, open: url, options: options)
    }
    
    
    
    // MARK: UISceneSession Lifecycle

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        
    }


}

