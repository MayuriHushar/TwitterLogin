//
//  naViewController.swift
//  twitterLoginDemo
//
//  Created by admin on 12/10/21.
//

import UIKit

class naViewController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
