//
//  ListViewController.swift
//  twitterLoginDemo
//
//  Created by admin on 09/10/21.
//

import UIKit
import SVProgressHUD
import TwitterKit

class ListViewController: UIViewController {

    var tableview : UITableView!
    var users = [listDetailsModel]()
    var page: String! = "-1"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        let screenSize = UIScreen.main.bounds
        
        
        let backButton: UIBarButtonItem = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(back))
            self.navigationItem.leftBarButtonItem = backButton
        
        callListWebService()
        
        tableview = UITableView()
        tableview.frame = CGRect(x: 0, y: screenSize.height * 0.12, width: screenSize.width, height: screenSize.height * 0.88)
        tableview.backgroundColor = .clear
        tableview.dataSource = self
        tableview.delegate = self
        tableview.separatorStyle = .singleLine
        tableview.isScrollEnabled = true
        tableview.register(ListTableViewCell.self, forCellReuseIdentifier: "cell")
        tableview.clipsToBounds=true
        view.addSubview(tableview)
        
    }
}


extension ListViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ListTableViewCell
        cell.nameLabel.text = users[indexPath.row].name
        cell.myuserNameLabel.text = "@"+users[indexPath.row].screen_name! ?? ""
        cell.profileImgView.sd_setImage(with: URL(string: users[indexPath.row].profile_image_url_https ?? ""), placeholderImage: UIImage(named: "placeholder.png"))
      
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let screenSize = UIScreen.main.bounds
        return screenSize.height * 0.14
    }
    
    func tableView(_ tableView: UITableView,viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        let lastElement = self.users.count - 1
        if indexPath.row == lastElement {
            
        }
        else {
          
        }
       }
    
    func scrollViewWillBeginDecelerating(_ scrollView: UIScrollView) {
        
        if scrollView == self.tableview {
            if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height){
                
               callListWebService()
            }
        }
    }
    
    
}

extension ListViewController {
    func  callListWebService(){
        if isfollowing{
            
            getFollowingList(with: "https://api.twitter.com/1.1/friends/list.json", params: ["user_id":UserDefaults.standard.string(forKey: "UserID"),"count":"20","cursor":self.page], withMethod: "GET")
        }
        else {
            getFollowerList(with: "https://api.twitter.com/1.1/followers/list.json", params: ["user_id":UserDefaults.standard.string(forKey: "UserID"),"count":"20","cursor":self.page], withMethod: "GET")
        }
    }
    
    private func getFollowingList(with Api:String,params:[String:Any], withMethod:String){
        
        if self.page == "0"{
            print("user not found")
        }else{
        let client = TWTRAPIClient.withCurrentUser()
        var clientError : NSError?
        let request = client.urlRequest(withMethod: withMethod, urlString: Api, parameters: params, error: &clientError)
        client.sendTwitterRequest(request) { (response, data, connectionError) -> Void in
            if connectionError != nil {
                print("Error: \(connectionError)")
            }
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: [])
                print("json: \(json)")
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(FriendDetailsModel?.self, from: data!)
                self.page = responseModel?.next_cursor_str
                if responseModel?.users == nil || responseModel?.users?.count == 0{
                
                }else{
                    self.users += (responseModel?.users)!
                    if self.users.count > 0 {
                        self.tableview.reloadData()
                    }
                }
               
            }
            
            catch let jsonError as NSError {
                print("json error: \(jsonError.localizedDescription)")
            }
        }
        }
    }
  
    private func getFollowerList(with Api:String,params:[String:Any], withMethod:String){
        if self.page == "0"{
                    print("user not found")
                }else{
        let client = TWTRAPIClient.withCurrentUser()
        var clientError : NSError?
        let request = client.urlRequest(withMethod: withMethod, urlString: Api, parameters: params, error: &clientError)
        client.sendTwitterRequest(request) { (response, data, connectionError) -> Void in
            if connectionError != nil {
                print("Error: \(connectionError)")
            }
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: [])
                print("json: \(json)")
                let jsonDecoder = JSONDecoder()
                let responseModel = try jsonDecoder.decode(FriendDetailsModel?.self, from: data!)
                self.page = responseModel?.next_cursor_str
                if responseModel?.users == nil || responseModel?.users?.count == 0{
                }
                else{
                self.users += (responseModel?.users)!
                if self.users.count > 0 {
                self.tableview.reloadData()
                }
            }
               
            }
            catch let jsonError as NSError {
                print("json error: \(jsonError.localizedDescription)")
            }
        }
     }
    }
    
    
    
}
extension ListViewController {
    // back btn action
    
   
    @objc func back() {
        isfollower = false
        isfollowing = false
        navigationController?.popViewController(animated: true)
    }
    
}
