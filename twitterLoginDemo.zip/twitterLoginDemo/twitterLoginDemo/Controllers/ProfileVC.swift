//
//  ProfileVC.swift
//  twitterLoginDemo
//
//  Created by admin on 09/10/21.
//

import UIKit
import TwitterKit
import SVProgressHUD
import SDWebImage

class ProfileVC: UIViewController {

    var scrollview : UIScrollView!
    var myView : UIView!
    var imgview : UIImageView!
    var myusernameLabel : UILabel!
    var usernameLabel : UILabel!
    var followingBtn : UIButton!
    var followerBtn : UIButton!
    var followingCount : UILabel!
    var followerCount : UILabel!
    
    var store: TWTRSessionStore?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        store=TWTRTwitter.sharedInstance().sessionStore
        callWebService()
     }
    
    func setupUI(){
        navigationController?.setNavigationBarHidden(false, animated: true)
        navigationController?.navigationBar.barTintColor =  hexStringToUIColor(hex: "1E90FF")
        let button1 = UIBarButtonItem(image: UIImage(named: "logout"), style: .plain, target: self, action:  #selector(LogOutClick))
        button1.setTitleTextAttributes([NSAttributedString.Key.foregroundColor:UIColor.white, NSAttributedString.Key.font:UIFont(name:"HelveticaNeue", size: 18)!], for: .normal)
        self.navigationItem.rightBarButtonItem  = button1
        self.navigationItem.hidesBackButton = true
        title = "Profile"
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor:UIColor.white, NSAttributedString.Key.font:UIFont(name:"HelveticaNeue", size: 18)!]
        
        let screenSize = UIScreen.main.bounds
        
        var hegt = screenSize.height * 0.14

        imgview = UIImageView()
        imgview.frame = CGRect(x:(screenSize.width/2)-screenSize.width * 0.15, y:hegt, width: screenSize.width * 0.30, height: screenSize.width * 0.30)
        imgview.image = #imageLiteral(resourceName: "profile.png")
        imgview.layer.borderWidth = 1
        imgview.layer.masksToBounds = false
        imgview.layer.borderColor = UIColor.black.cgColor
        imgview.layer.cornerRadius = imgview.frame.height/2
        imgview.clipsToBounds = true
        view.addSubview(imgview)
        
        hegt = hegt+screenSize.width*0.35
        
        myusernameLabel = UILabel()
        
        myusernameLabel.font = UIFont.boldSystemFont(ofSize: screenSize.width * 0.04)
        myusernameLabel.textColor = UIColor.black
        myusernameLabel.textAlignment = .left
        myusernameLabel.frame = CGRect(x: (screenSize.width/2)-screenSize.width * 0.15, y: hegt, width: screenSize.width * 0.70, height: screenSize.height * 0.04)
        view.addSubview(myusernameLabel)
        
        hegt = hegt+screenSize.height*0.03
        
        usernameLabel = UILabel()
        usernameLabel.font = UIFont.systemFont(ofSize: screenSize.width * 0.04)
        usernameLabel.textColor = UIColor.black
        usernameLabel.textAlignment = .left
        usernameLabel.frame = CGRect(x: (screenSize.width/2)-screenSize.width * 0.15, y: hegt, width: screenSize.width * 0.70, height: screenSize.height * 0.04)
        view.addSubview(usernameLabel)
        
        hegt = hegt+screenSize.height*0.05
        
        followingCount = UILabel()
        followingCount.font = UIFont.boldSystemFont(ofSize: screenSize.width * 0.04)
        followingCount.textColor = UIColor.black
        followingCount.textAlignment = .left
        followingCount.frame = CGRect(x: screenSize.width * 0.15, y: hegt, width: screenSize.width * 0.08, height: screenSize.height * 0.04)
        view.addSubview(followingCount)
        
        followingBtn  = UIButton()
        followingBtn.frame = CGRect(x: screenSize.width * 0.24, y: hegt, width: screenSize.width * 0.30, height: screenSize.height * 0.04)
        followingBtn.setTitle("Following", for: .normal)
        followingBtn.setTitleColor(UIColor.black, for: .normal)
        followingBtn.contentHorizontalAlignment = .left
        followingBtn.titleLabel?.font = UIFont.systemFont(ofSize: screenSize.width * 0.04)
        followingBtn.addTarget(self, action: #selector(BtnFollowingClick), for: .touchUpInside)
        view.addSubview(followingBtn)
        
        followerCount = UILabel()
        followerCount.font = UIFont.boldSystemFont(ofSize: screenSize.width * 0.04)
        followerCount.textColor = UIColor.black
        followerCount.textAlignment = .left
        followerCount.frame = CGRect(x: screenSize.width * 0.60, y: hegt, width: screenSize.width * 0.08, height: screenSize.height * 0.04)
        view.addSubview(followerCount)
        
        followerBtn  = UIButton()
        followerBtn.frame = CGRect(x: screenSize.width * 0.69, y: hegt, width: screenSize.width * 0.30, height: screenSize.height * 0.04)
        followerBtn.setTitle("Follower", for: .normal)
        followerBtn.titleLabel?.font = UIFont.systemFont(ofSize: screenSize.width * 0.04)
        followerBtn.setTitleColor(UIColor.black, for: .normal)
        followerBtn.contentHorizontalAlignment = .left
        followerBtn.addTarget(self, action: #selector(BtnFollowerClick), for: .touchUpInside)
        view.addSubview(followerBtn)
        
    }
    
}

extension ProfileVC {
    // Actions Of Buttons
   @objc func BtnFollowingClick(){
        print("following click")
    let vc  : ListViewController = ListViewController()
    vc.title = "Following"
    isfollowing = true
    self.navigationController?.pushViewController(vc, animated: true)
    
    }
    
    @objc func BtnFollowerClick(){
    print("follower click")
        let vc  : ListViewController = ListViewController()
        vc.title = "Follower"
        isfollower = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func LogOutClick () {
        
        UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
        UserDefaults.standard.synchronize()
        UserDefaults.standard.setValue(false, forKey: "isloggedIn")
       
        if let userID = store!.session()?.userID{
            store!.logOutUserID(userID)
        }
        
        let mainaNav = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController
        self.present(mainaNav!, animated: false, completion: nil)
        
        
    }
    
}

extension ProfileVC {
    func callWebService()
    {
        sendReqFollowingCount(with: "https://api.twitter.com/1.1/friends/ids.json", params: ["id":UserDefaults.standard.string(forKey: "UserID")], withMethod: "GET")
  
        getTwitterUserReqwest(with: "https://api.twitter.com/1.1/users/show.json", params: ["id":UserDefaults.standard.string(forKey: "UserID")], withMethod: "GET")

        
        
    }
    private func sendReqFollowingCount(with Api:String,params:[String:Any], withMethod:String){
        
        
        let client = TWTRAPIClient.withCurrentUser()
        
        var clientError : NSError?
        
        let request = client.urlRequest(withMethod: withMethod, urlString: Api, parameters: params, error: &clientError)
        
        client.sendTwitterRequest(request) { (response, data, connectionError) -> Void in
            if connectionError != nil {
                print("Error: \(connectionError)")
            }
            
            
            do {
                
                let json = try JSONSerialization.jsonObject(with: data!, options: [])
                print("json: \(json)")
                
                
                let jsonDecoder = JSONDecoder()
                
                let responseModel = try jsonDecoder.decode(countModel?.self, from: data!)
                
                print(responseModel?.ids?.count)
                
                self.followingCount.text = String((responseModel?.ids!.count)!)
            }
            
            
            catch let jsonError as NSError {
                print("json error: \(jsonError.localizedDescription)")
            }
        }
    }
    
    private func getTwitterUserReqwest(with Api:String,params:[String:Any], withMethod:String){
        
        
        let client = TWTRAPIClient.withCurrentUser()
        
        var clientError : NSError?
        
        let request = client.urlRequest(withMethod: withMethod, urlString: Api, parameters: params, error: &clientError)
        
        client.sendTwitterRequest(request) { (response, data, connectionError) -> Void in
            if connectionError != nil {
                print("Error: \(connectionError)")
            }
            
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: [])
                print("json: \(json)")
                
                
                let jsonDecoder = JSONDecoder()
                
                let responseModel = try jsonDecoder.decode(userDetailsModel?.self, from: data!)
                
                self.myusernameLabel.text = responseModel?.name
                self.usernameLabel.text = "@"+(responseModel?.screen_name)! ?? ""
                self.followingCount.text = String(responseModel?.friends_count ?? 0)
                self.followerCount.text = String(responseModel?.followers_count ?? 0)
                self.imgview.sd_setImage(with: URL(string: responseModel?.profile_image_url_https ?? ""), placeholderImage: UIImage(named: "placeholder.png"))
            }
            
            catch let jsonError as NSError {
                print("json error: \(jsonError.localizedDescription)")
            }
        }
        
    }
    
    
    
}
