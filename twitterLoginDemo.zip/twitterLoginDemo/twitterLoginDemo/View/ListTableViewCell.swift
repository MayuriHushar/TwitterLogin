//
//  ListTableViewCell.swift
//  twitterLoginDemo
//
//  Created by admin on 09/10/21.
//

import UIKit

class ListTableViewCell: UITableViewCell {
    let bgView = UIView()
    let nameLabel = UILabel()
    let myuserNameLabel = UILabel()
    let profileImgView = UIImageView()
    var Btn = UIButton()
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style , reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        
        let screenSize = UIScreen.main.bounds
        var hegt = screenSize.height * 0.00
        
        bgView.backgroundColor = UIColor.white
        bgView.frame = CGRect(x: 0 , y: hegt, width: screenSize.width, height: screenSize.height * 0.14)
        contentView.addSubview(bgView)
       
        
      
        profileImgView.frame = CGRect(x:screenSize.width * 0.04, y:hegt+screenSize.height * 0.01, width: screenSize.width * 0.20, height: screenSize.width * 0.20)
        profileImgView.image = #imageLiteral(resourceName: "profile.png")
        profileImgView.layer.borderWidth = 1
        profileImgView.layer.masksToBounds = false
        profileImgView.layer.borderColor = UIColor.black.cgColor
        profileImgView.layer.cornerRadius = profileImgView.frame.height/2
        profileImgView.clipsToBounds = true
        contentView.addSubview(profileImgView)
        
        
        nameLabel.textColor = UIColor.black
        nameLabel.textAlignment = .left
        nameLabel.font = UIFont.boldSystemFont(ofSize: screenSize.width * 0.044)
        nameLabel.frame = CGRect(x: screenSize.width * 0.26, y: hegt+screenSize.height * 0.02, width: screenSize.width * 0.70, height: screenSize.height * 0.05)
        nameLabel.numberOfLines = 0
        contentView.addSubview(nameLabel)

        hegt = hegt + screenSize.height * 0.06
        
        myuserNameLabel.textColor = UIColor.black
        myuserNameLabel.textAlignment = .left
        myuserNameLabel.font = UIFont.systemFont(ofSize: screenSize.width * 0.042)
        myuserNameLabel.frame = CGRect(x: screenSize.width * 0.26, y: hegt, width: screenSize.width * 0.70, height: screenSize.height * 0.038)
        myuserNameLabel.numberOfLines = 0
        contentView.addSubview(myuserNameLabel)
        hegt = hegt + screenSize.height * 0.05
        
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
