//
//  ViewController.swift
//  twitterLoginDemo
//
//  Created by admin on 09/10/21.
//

import UIKit
import TwitterKit

class ViewController: UIViewController {
   
    var loginButton : UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        let screenSize = UIScreen.main.bounds
        navigationController?.setNavigationBarHidden(true, animated: true)
        loginButton = UIButton()
        loginButton.setTitle("Login", for: .normal)
        loginButton.setTitleColor(UIColor.white, for: .normal)
        loginButton.frame = CGRect(x: screenSize.width * 0.03, y: screenSize.height * 0.40, width: screenSize.width * 0.94, height: screenSize.height * 0.06)
        loginButton.addTarget(self, action: #selector(loginAction), for: .touchUpInside)
        loginButton.contentHorizontalAlignment = .center
        loginButton.backgroundColor = hexStringToUIColor(hex: "1E90FF")
        loginButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: screenSize.width*0.042)
        loginButton.layer.cornerRadius=5
        view.addSubview(loginButton)
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
}

extension ViewController {
    // Actions Of Buttons
   @objc func loginAction(){
    
    TWTRTwitter.sharedInstance().logIn { (session, error) in
        if session != nil {
            print("Log in successfully")
            UserDefaults.standard.setValue(session?.userID, forKey: "UserID")
            UserDefaults.standard.setValue(true, forKey: "isloggedIn")
            
            let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "naViewController") as? naViewController
            self.navigationController?.pushViewController(vc!, animated: true)
            
            let mainaNav = self.storyboard?.instantiateViewController(withIdentifier: "naViewController") as? naViewController
            self.present(mainaNav!, animated: false, completion: nil)
            
        }else{
            print(error.debugDescription)
        }
        
    }
    

    
    }
}
