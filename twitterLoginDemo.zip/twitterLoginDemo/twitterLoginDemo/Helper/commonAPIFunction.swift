//
//  commonAPIFunction.swift
//  OnlineOpd
//
//  Created by sparken on 14/09/20.
//  Copyright © 2020 SparkenITSolution. All rights reserved.
//

import Foundation
import SVProgressHUD
import CommonCrypto

class apicall: NSObject {
   
    func callGETWebService(_ url_String: String, parameetrs: String, method: String, completion: @escaping ([String: Any]?, Error?)->()) {
        var appDelegate : AppDelegate?
        appDelegate = UIApplication.shared.delegate as? AppDelegate
        var request = URLRequest(url: URL(string: url_String)!)
        request.httpMethod = method
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let task = URLSession.shared.dataTask(with: request) {
            data, response, error in
            if error != nil {
                SVProgressHUD.dismiss()
                print("error = \(error ?? 0 as! Error)")
                DispatchQueue.main.async(execute: {() -> Void in
                    completion( nil , error)
                })
                return
            }
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            var dictonary:NSDictionary?
            let user = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
            DispatchQueue.main.async(execute: {() -> Void in
                if let user = user {
                    completion(user, nil)
                } else {
                    print("Request URL: \(url_String)\nResponse String: \(String(data: data!, encoding: .ascii) as Any)")
                    completion(nil , error)
                }
            })
            
            
            DispatchQueue.main.async(execute: {() -> Void in
                if let user = user {
                    completion(user as! [String : Any] , nil)
                } else {
                    SVProgressHUD.dismiss()
                    completion( nil , error)
                }
            })
        }
        task.resume()
    }
    
    
    
    
    
}

